<?php

class Categoria {
    
    public function index() {
        // Instancia del modelo
        $categoriaModel = new CategoriaModel();
        
        // Método del modelo para obtener todas las categorías
        $response = $categoriaModel->index();
        
        // Verificar si se encontraron categorías
        if (!empty($response)) {
            // Preparar la respuesta en formato JSON
            $json = array(
                'status' => 200,
                'results' => $response
            );
        }else{
            $json=array(
                'status'=>400,
                'results'=>"No hay registros"
            );
        }
        echo json_encode($json,
                http_response_code($json["status"])
            );
    }
    
    public function obtenerCategoria($id) {
        // Instancia del modelo
        $categoriaModel = new CategoriaModel();
        
        // Método del modelo para obtener una categoría por ID
        $response = $categoriaModel->obtenerCategoria($id);
        
        // Verificar si se encontró la categoría
        if (!empty($response)) {
            // Preparar la respuesta en formato JSON
            $json = array(
                'status' => 200,
                'results' => $response
            );
        } else {
            // No se encontró la categoría
            $json = array(
                'status' => 404,
                'results' => "No se encontró la categoría solicitada"
            );
        }
        
        // Devolver la respuesta como JSON
        header('Content-Type: application/json');
        http_response_code($json["status"]);
        echo json_encode($json);
    }
}

?>
