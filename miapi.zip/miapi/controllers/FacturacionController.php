<?php

class Factura{

    public function index() {
        // Instancia del modelo de facturas
        $facturaModel = new FacturacionModel();
        
        // Obtener todas las facturas
        $response = $facturaModel->index();
        
        if ($response) {
            $json = array(
                'status' => 200,
                'results' => $response
            );
        } else {
            $json = array(
                'status' => 400,
                'results' => "No hay registros de facturas"
            );
        }
        
        // Devolver respuesta como JSON
        http_response_code($json["status"]);
        echo json_encode($json);
    }

    public function obtenerFactura($id) {
        // Instancia del modelo de facturas
        $facturaModel = new FacturacionModel();
        
        // Obtener la factura por ID
        $response = $facturaModel->obtenerFactura($id);
        
        if ($response) {
            $json = array(
                'status' => 200,
                'results' => $response
            );
        } else {
            $json = array(
                'status' => 400,
                'results' => "No existe la factura solicitada"
            );
        }
        
        // Devolver respuesta como JSON
        http_response_code($json["status"]);
        echo json_encode($json);
    }

}