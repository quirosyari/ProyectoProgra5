<?php

class Reserva
{
    public function index()
    {
        // Supongamos que obtienes el ID de la sucursal desde algún contexto, por ejemplo, una variable de sesión o autenticación
        $idSucursal = 1; // Aquí deberías obtener el ID de la sucursal de acuerdo a tu lógica de negocio

        // Instancia del modelo
        $reservaModel = new ReservaModel();
        
        // Método del modelo para obtener todas las reservas
        $reservas = $reservaModel->listarReservasEncargado($idSucursal);

        // Verificar si se encontraron reservas
        if (!empty($reservas)) {
            // Preparar la respuesta en formato JSON
            $json = array(
                'status' => 200,
                'results' => $reservas
            );
        } else {
            // No se encontraron reservas
            $json = array(
                'status' => 404,
                'results' => "No hay reservas registradas"
            );
        }

        // Devolver la respuesta como JSON
        header('Content-Type: application/json');
        http_response_code($json["status"]);
        echo json_encode($json);
    }

    public function show($id)
    {
        // Instancia del modelo
        $reservaModel = new ReservaModel();
        
        // Método del modelo para obtener una reserva por ID
        $reserva = $reservaModel->obtenerDetalleReserva($id);

        // Verificar si se encontró la reserva
        if (!empty($reserva)) {
            // Preparar la respuesta en formato JSON
            $json = array(
                'status' => 200,
                'results' => $reserva
            );
        } else {
            // No se encontró la reserva
            $json = array(
                'status' => 404,
                'results' => "No se encontró la reserva solicitada"
            );
        }

        // Devolver la respuesta como JSON
        header('Content-Type: application/json');
        http_response_code($json["status"]);
        echo json_encode($json);
    }
}
