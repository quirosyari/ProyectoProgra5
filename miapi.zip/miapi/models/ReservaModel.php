<?php

class ReservaModel
{
    public $enlace;

    public function __construct()
    {
        $this->enlace = new MySqlConnect();
    }

    /**
     * Lista las reservas para un encargado, mostrando como máximo 4 campos.
     * Incluye el estado de la cita con su respectivo color.
     * Filtra por la sucursal del encargado.
     * 
     * @param int $idSucursal ID de la sucursal del encargado
     * @return array Lista de reservas
     */
    public function listarReservasEncargado($idSucursal)
    {
        try {
            $vSql = "SELECT r.id_reserva, r.fecha_generacion, r.hora, s.nombre AS nombre_sucursal, se.nombre AS nombre_servicio, r.estado
                     FROM Reservas r
                     JOIN Sucursales s ON r.id_sucursal = s.id_sucursal
                     JOIN Servicios se ON r.id_servicio = se.id_servicio
                     WHERE r.id_sucursal = $idSucursal
                     LIMIT 3"; // Limitamos a 3 citas como máximo por sucursal

            $vResultado = $this->enlace->ExecuteSQL($vSql);

            return $vResultado;
        } catch (Exception $e) {
            die($e->getMessage());
        }
    }

    /**
     * Obtiene el detalle completo de una reserva.
     * 
     * @param int $idReserva ID de la reserva
     * @return object|null Detalle de la reserva o null si no existe
     */
    public function obtenerDetalleReserva($idReserva)
    {
        try {
            $vSql = "SELECT r.id_reserva, r.fecha_generacion, r.hora, s.nombre AS nombre_sucursal, se.nombre AS nombre_servicio, 
                            r.pregunta1, r.respuesta1, r.pregunta2, r.respuesta2, r.pregunta3, r.respuesta3, r.estado
                     FROM Reservas r
                     JOIN Sucursales s ON r.id_sucursal = s.id_sucursal
                     JOIN Servicios se ON r.id_servicio = se.id_servicio
                     WHERE r.id_reserva = $idReserva";

            $vResultado = $this->enlace->ExecuteSQL($vSql);

            return !empty($vResultado) ? $vResultado[0] : null;
        } catch (Exception $e) {
            die($e->getMessage());
        }
    }
}
