<?php

class FacturacionModel
{
    public $enlace;

    public function __construct()
    {
        $this->enlace = new MySqlConnect();
    }

    /**
     * Listar facturaciones más recientes
     * @return array Lista de objetos de facturación
     */
    public function index()
    {
        try {
                        // Consulta SQL para obtener las facturaciones más recientes
                        $vSql = "SELECT id_factura, fecha_factura, total, motivo
                        FROM facturas
                        ORDER BY fecha_factura DESC;";
            $vResultado = $this->enlace->ExecuteSQL($vSql);
            return $vResultado;
        } catch (Exception $e) {
            die($e->getMessage());
        }
    }

    /**
     * Obtener detalle completo de una factura por su ID
     * @param int $id ID de la factura
     * @return object Detalle completo de la factura
     */
    public function obtenerFactura($id)
    {
        try {
            // Consulta SQL para obtener el detalle completo de la factura
                                                    $vSql = "SELECT
    f.id_factura AS ID_Factura,
    f.fecha_factura AS Fecha,
    CONCAT(u.nombre, ' (ID: ', u.id_usuario, ')') AS Cliente,
    s.nombre AS Nombre_Sucursal,
    s.telefono AS Telefono_Sucursal,
    s.direccion_exacta AS Direccion_Sucursal,
    CONCAT('[', GROUP_CONCAT(
        JSON_OBJECT(
            'Nombre_Producto', p.nombre,
            'Cantidad', vp.cantidad,
            'Precio_Unitario', p.precio,
            'Subtotal_Item', (vp.cantidad * p.precio)
        )
        ORDER BY vp.id_venta_producto
    ), ']') AS Detalle_Productos,
    SUM(vp.cantidad * p.precio) AS Subtotal_Factura,
    SUM(vp.cantidad * p.precio * 0.13) AS Impuestos_Factura,
    SUM(vp.cantidad * p.precio * 1.13) AS Total_Factura
FROM
    facturas f
    JOIN usuarios u ON f.id_cliente = u.id_usuario
    JOIN sucursales s ON f.id_sucursal = s.id_sucursal
    JOIN ventas_productos vp ON f.id_factura = vp.id_factura
    JOIN productos p ON vp.id_producto = p.id_producto
WHERE
    f.id_factura = '$id'
GROUP BY
    f.id_factura, f.fecha_factura, u.nombre, u.id_usuario, s.nombre, s.telefono, s.direccion_exacta;
";
            $vResultado = $this->enlace->ExecuteSQL($vSql);
            return !empty($vResultado) ? $vResultado[0] : null;
        } catch (Exception $e) {
            die($e->getMessage());
        }
    }
}

