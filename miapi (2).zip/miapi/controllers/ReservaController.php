<?php
class Reserva
{



    public function listarReservas($idUsuario)
    {
        $movie = new ReservaModel();
        //Acción del modelo a ejecutar
        $response = $movie->listarReservas($idUsuario);
        //Verificar respuesta
        if (isset($response) && !empty($response)) {
            //Armar el JSON respuesta satisfactoria
            $json = array(
                'status' => 200,
                'results' => $response
            );
        } else {
            //JSON respuesta negativa
            $json = array(
                'status' => 400,
                'results' => "No existe el producto solicitado"
            );
        }
        //Escribir respuesta JSON con código de estado HTTP
        echo json_encode(
            $json,
            http_response_code($json["status"])
        );
}
}

