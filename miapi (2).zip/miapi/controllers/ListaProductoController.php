<?php

class Listado
{
    public function index()
    {
        // Instancia del modelo
        $productModel = new ListProductoModel();
        
        // Método del modelo para obtener todos los productos
        $response = $productModel->index();
        
        // Verificar si hay resultados
        if (!empty($response)) {
            $json = array(
                'status' => 200,
                'results' => $response
            );
        } else {
            $json = array(
                'status' => 400,
                'results' => "No hay registros de productos"
            );
        }
        
        // Devolver la respuesta como JSON
        header('Content-Type: application/json');
        http_response_code($json["status"]);
        echo json_encode($json);
    }

    public function get($id)
    {
        // Instancia del modelo
        $productModel = new ListProductoModel();
        
        // Método del modelo para obtener un producto por ID
        $response = $productModel->obtenerProducto($id);
        
        // Verificar si se encontró el producto
        if (!empty($response)) {
            $json = array(
                'status' => 200,
                'results' => $response
            );
        } else {
            $json = array(
                'status' => 404,
                'results' => "No se encontró el producto solicitado"
            );
        }
        
        // Devolver la respuesta como JSON
        header('Content-Type: application/json');
        http_response_code($json["status"]);
        echo json_encode($json);
    }
}
