CREATE DATABASE IF NOT EXISTS optica_db;
USE optica_db;

-- Tabla Roles
CREATE TABLE Roles (
    id_rol INT AUTO_INCREMENT PRIMARY KEY,
    rol_nombre VARCHAR(100) NOT NULL
);
-- Insertar datos en la tabla Roles
INSERT INTO Roles (rol_nombre) VALUES
    ('Administrador'),
    ('Empleado'),
    ('Cliente');

-- Tabla Usuarios
CREATE TABLE Usuarios (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    telefono VARCHAR(20),
    correo_electronico VARCHAR(100) NOT NULL,
    direccion_exacta VARCHAR(255),
    fecha_nacimiento DATE,
    contraseña VARCHAR(255) NOT NULL,
    id_rol INT NOT NULL,
    FOREIGN KEY (id_rol) REFERENCES Roles(id_rol)
);
-- Insertar datos en la tabla Usuarios
INSERT INTO Usuarios (nombre, telefono, correo_electronico, direccion_exacta, fecha_nacimiento, contraseña, id_rol) VALUES
    ('Yariela Quiros', '83019522', 'yarielaquiros7@gmail.com', '123 Calle Principal, San José, Carmen', '1990-01-15', 'contraseña123', 1), -- Administrador
    ('Alejandra Quiros', '84051307', 'alequiros18@gmail.com', '456 Calle Secundaria, San José, San Antonio', '1995-05-20', 'secreto456', 2), -- Empleado
    ('Roger Gamboa', '98765432', 'rogerbambio11@gmail.com', '789 Calle Terciaria, Nicoya, Mansión', '1985-10-10', 'clave789', 3); -- Cliente

-- Tabla Sucursales
CREATE TABLE Sucursales (
    id_sucursal INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    telefono VARCHAR(20),
    direccion_exacta VARCHAR(255),
    correo_electronico VARCHAR(100)
);
-- Insertar datos en la tabla Sucursales
INSERT INTO Sucursales (nombre, descripcion, telefono, direccion_exacta, correo_electronico) VALUES
    ('Sucursal Central', 'Sucursal principal de AgendaVision', '2222-2222', 'Avenida Principal, San José, Carmen', 'info@sucursalcentral.com'),
    ('Sucursal Norte', 'Sucursal ubicada en el norte de la ciudad', '3333-3333', 'Calle Norte, Heredia, Barva', 'info@sucursalnorte.com'),
    ('Sucursal Oeste', 'Sucursal ubicada en el oeste de la ciudad', '4444-4444', 'Avenida Oeste, Alajuela, San Ramón', 'info@sucursaloeste.com');


-- Tabla Usuarios_Sucursales (relación muchos a muchos)
CREATE TABLE Usuarios_Sucursales (
    id_usuario_sucursal INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    id_sucursal INT NOT NULL,
    id_rol INT NOT NULL,
    FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario),
    FOREIGN KEY (id_sucursal) REFERENCES Sucursales(id_sucursal),
    FOREIGN KEY (id_rol) REFERENCES Roles(id_rol),
    UNIQUE (id_usuario, id_sucursal)
);
-- Insertar datos en la tabla Usuarios_Sucursales
INSERT INTO Usuarios_Sucursales (id_usuario, id_sucursal, id_rol) VALUES
    (1, 1, 1),  -- Yariela Quiros (Administrador) en Sucursal Central
    (2, 1, 2),  -- Alejandra Quiros (Empleado) en Sucursal Central
    (3, 2, 3);  -- Roger Gamboa (Cliente) en Sucursal Norte

-- Tabla Categorias
CREATE TABLE Categorias (
    id_categoria INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT
);
-- Insertar datos en la tabla Categorias
INSERT INTO Categorias (nombre, descripcion) VALUES
    ('Gafas', 'Categoría de gafas graduadas y de sol'),
    ('Lentes de Contacto', 'Categoría de lentes de contacto'),
    ('Accesorios para gafas', 'Accesorios para cuidado y mantenimiento de gafas'),
    ('Productos de limpieza', 'Productos para la limpieza de lentes y gafas');


-- Tabla Servicios
CREATE TABLE Servicios (
    id_servicio INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    tarifa DECIMAL(10, 2) NOT NULL,
    tiempo_servicio INT NOT NULL,
    campo_extra1 VARCHAR(255),
    campo_extra2 VARCHAR(255),
    id_categoria INT,
    FOREIGN KEY (id_categoria) REFERENCES Categorias(id_categoria)
);
-- Insertar datos en la tabla Servicios
INSERT INTO Servicios (nombre, descripcion, tarifa, tiempo_servicio, id_categoria) VALUES
    ('Examen de la Vista General', 'Examen de la vista completo.', 50000.00, 60, 1),
    ('Examen para Lentes de Contacto', 'Examen específico para adaptación de lentes de contacto.', 10000.00, 30, 2),  
    ('Examen Pediátrico', 'Examen de la vista para niños.', 150000.00, 30, 1),  
    ('Consulta General', 'Consulta oftalmológica general.', 50000.00, 60, 1), 
    ('Seguimiento de Tratamiento', 'Seguimiento de tratamiento oftalmológico.', 70000.00, 30, 1), 
    ('Adaptacion de lentes de contacto', 'Adaptación de lentes de contacto.', 70000.00, 60, 2),  
    ('Reparacion de gafas', 'Reparación de gafas.', 50000.00, 30, 3);  

-- Tabla Productos
CREATE TABLE Productos (
    id_producto INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    precio DECIMAL(10, 2) NOT NULL,
    campo_extra1 VARCHAR(255),
    campo_extra2 VARCHAR(255),
    id_categoria INT,
    FOREIGN KEY (id_categoria) REFERENCES Categorias(id_categoria)
);
INSERT INTO Productos (nombre, descripcion, precio, id_categoria) VALUES
    ('Gafas de Sol Clásicas', 'Gafas de sol con estilo clásico.', 25000.00, 1),  -- Categoría: Gafas
    ('Gafas de Sol Deportivas', 'Gafas de sol diseñadas para actividades deportivas.', 30000.00, 1),  -- Categoría: Gafas
    ('Gafas Graduadas Estilo Retro', 'Gafas graduadas con diseño retro.', 35000.00, 1),  -- Categoría: Gafas
    ('Lentes de Contacto Desechables', 'Lentes de contacto desechables mensuales.', 15000.00, 2),  -- Categoría: Lentes de Contacto
    ('Lentes de Contacto Tóricos', 'Lentes de contacto tóricos para corrección de astigmatismo.', 20000.00, 2),  -- Categoría: Lentes de Contacto
    ('Solución Multiuso para Lentes de Contacto', 'Solución para limpieza y almacenamiento de lentes de contacto.', 10000.00, 4),  -- Categoría: Productos de limpieza
    ('Toallitas Limpiadoras para Gafas', 'Toallitas especiales para limpiar gafas y lentes.', 5000.00, 3);  -- Categoría: Accesorios para gafas
-- Tabla Citas

-- Crear la tabla Citas con la nueva estructura
CREATE TABLE Citas (
    id_cita INT AUTO_INCREMENT PRIMARY KEY,
    id_cliente INT NOT NULL,
    id_optico INT NOT NULL,
    fecha_cita DATETIME NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fin TIME NOT NULL,
    id_sucursal INT NOT NULL,
    id_servicio INT NOT NULL,
    motivo_cita VARCHAR(255),
    estado_cita ENUM('Pendiente', 'Confirmada', 'Reprogramada', 'Completada', 'Cancelada', 'No asistió') NOT NULL,
    pregunta1 VARCHAR(255),
    pregunta2 VARCHAR(255),
    pregunta3 VARCHAR(255),
    FOREIGN KEY (id_cliente) REFERENCES Usuarios(id_usuario),
    FOREIGN KEY (id_optico) REFERENCES Usuarios(id_usuario),
    FOREIGN KEY (id_sucursal) REFERENCES Sucursales(id_sucursal),
    FOREIGN KEY (id_servicio) REFERENCES Servicios(id_servicio)
);
INSERT INTO Citas (id_cliente, id_optico, fecha_cita, hora_inicio, hora_fin, id_sucursal, id_servicio, motivo_cita, estado_cita, pregunta1, pregunta2, pregunta3)
VALUES
    (1, 2, '2024-06-15 10:00:00', '09:00:00', '10:00:00', 1, 1, 'Examen de la Vista', 'Confirmada', 'Pregunta 1', 'Pregunta 2', 'Pregunta 3');

-- Tabla Horarios
CREATE TABLE Horarios (
    id_horario INT AUTO_INCREMENT PRIMARY KEY,
    id_sucursal INT NOT NULL,
    dia_semana ENUM('Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo') NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fin TIME NOT NULL,
    UNIQUE KEY unique_horario (id_sucursal, dia_semana),
    FOREIGN KEY (id_sucursal) REFERENCES Sucursales(id_sucursal)
);
-- Insertar ejemplo de horarios para una sucursal
INSERT INTO Horarios (id_sucursal, dia_semana, hora_inicio, hora_fin)
VALUES
    (1, 'Lunes', '08:00:00', '16:00:00'),
    (1, 'Martes', '08:00:00', '16:00:00'),
    (1, 'Miércoles', '08:00:00', '16:00:00'),
    (1, 'Jueves', '08:00:00', '16:00:00'),
    (1, 'Viernes', '08:00:00', '16:00:00'),
    (1, 'Sábado', '09:00:00', '13:00:00'),
    (1, 'Domingo', '09:00:00', '13:00:00');


-- Tabla Bloqueos
CREATE TABLE Bloqueos (
    id_bloqueo INT AUTO_INCREMENT PRIMARY KEY,
    id_sucursal INT NOT NULL,
    fecha_bloqueo DATE NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fin TIME NOT NULL,
    FOREIGN KEY (id_sucursal) REFERENCES Sucursales(id_sucursal)
);

-- Tabla Facturas
CREATE TABLE Facturas (
    id_factura INT AUTO_INCREMENT PRIMARY KEY,
    id_cliente INT NOT NULL,
    id_sucursal INT NOT NULL,
    fecha_factura DATETIME NOT NULL,
    subtotal DECIMAL(10, 2) NOT NULL,
    impuestos DECIMAL(10, 2) NOT NULL,
    total DECIMAL(10, 2) NOT NULL,
    estado_envio_comprobante BOOLEAN DEFAULT FALSE,
    motivo VARCHAR(255) NOT NULL,
    FOREIGN KEY (id_cliente) REFERENCES Usuarios(id_usuario),
    FOREIGN KEY (id_sucursal) REFERENCES Sucursales(id_sucursal)
);
INSERT INTO Facturas (id_cliente, id_sucursal, fecha_factura, subtotal, impuestos, total, estado_envio_comprobante, motivo)
VALUES
    (1, 1, '2024-06-07 14:30:00', 320.00, 48.00, 368.00, FALSE, 'Compra de productos');


-- Tabla Ventas_Productos
CREATE TABLE Ventas_Productos (
    id_venta_producto INT AUTO_INCREMENT PRIMARY KEY,
    id_factura INT NOT NULL,
    id_producto INT NOT NULL,
    cantidad INT NOT NULL,
    precio_unitario DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (id_factura) REFERENCES Facturas(id_factura),
    FOREIGN KEY (id_producto) REFERENCES Productos(id_producto)
);
-- Insertar ejemplo de ventas de productos para una factura
INSERT INTO Ventas_Productos (id_factura, id_producto, cantidad, precio_unitario)
VALUES
    (1, 1, 2, 250.00), -- 2 unidades del producto 1 a $250.00 cada una
    (1, 3, 1, 120.00); -- 1 unidad del producto 3 a $120.00


-- Tabla Reservas
CREATE TABLE Reservas (
    id_reserva INT AUTO_INCREMENT PRIMARY KEY,
    id_cita INT,
    id_producto INT,
    id_servicio INT,
    id_factura INT,
    id_cliente INT NOT NULL,
    id_sucursal INT NOT NULL,
    fecha_reserva DATETIME NOT NULL,
    estado_reserva ENUM('Pendiente', 'Confirmada', 'Reprogramada', 'Completada', 'Cancelada', 'No asistió') NOT NULL,
    estado_pago ENUM('Pendiente', 'Pagado') DEFAULT 'Pendiente',
    FOREIGN KEY (id_cita) REFERENCES Citas(id_cita),
    FOREIGN KEY (id_producto) REFERENCES Productos(id_producto),
    FOREIGN KEY (id_servicio) REFERENCES Servicios(id_servicio),
    FOREIGN KEY (id_factura) REFERENCES Facturas(id_factura),
    FOREIGN KEY (id_cliente) REFERENCES Usuarios(id_usuario),
    FOREIGN KEY (id_sucursal) REFERENCES Sucursales(id_sucursal)
);

INSERT INTO Reservas (id_cliente, id_sucursal, fecha_reserva, estado_reserva, estado_pago)
VALUES (1, 1, '2024-06-10 10:00:00', 'Pendiente', 'Pendiente');

-- Tabla de Sesiones
CREATE TABLE Sesiones (
    id_sesion INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    token VARCHAR(255) NOT NULL,
    fecha_expiracion DATETIME NOT NULL,
    FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario)
);
-- Insertar sesiones de ejemplo
INSERT INTO Sesiones (id_usuario, token, fecha_expiracion) VALUES
(1, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9', '2024-06-08 12:00:00'),
(2, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9', '2024-06-09 10:30:00'),
(3, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9', '2024-06-10 15:45:00');


-- Recuperación de Contraseña
ALTER TABLE Usuarios
ADD COLUMN codigo_recuperacion VARCHAR(255),
ADD COLUMN fecha_expiracion_recuperacion DATETIME;

-- Inventario de Productos
ALTER TABLE Productos
ADD COLUMN cantidad_inventario INT DEFAULT 0,
ADD COLUMN cantidad_minima INT DEFAULT 0;


-- Bitácora de Actividades
CREATE TABLE Bitacora (
    id_bitacora INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    fecha_hora DATETIME NOT NULL,
    accion VARCHAR(255) NOT NULL,
    FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario)
);
-- Insertar registros en la tabla Bitacora
INSERT INTO Bitacora (id_usuario, fecha_hora, accion) VALUES
(1, '2024-06-08 10:00:00', 'Acceso al sistema'),
(2, '2024-06-08 11:30:00', 'Actualización de datos de cliente'),
(3, '2024-06-08 14:45:00', 'Eliminación de producto'),
(1, '2024-06-09 09:15:00', 'Creación de nueva cita'),
(2, '2024-06-09 13:20:00', 'Generación de factura');

-- 
-- Historial de Usuarios
CREATE TABLE Historial_Usuarios (
    id_historial INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    fecha_hora DATETIME NOT NULL,
    datos_anteriores JSON,
    datos_nuevos JSON,
    tipo_operacion VARCHAR(50) NOT NULL,
    FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario)
);

-- Tabla Provincias
CREATE TABLE Provincias (
    id_provincia INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL
);
INSERT INTO Provincias (nombre) VALUES
    ('San José'),
    ('Alajuela'),
    ('Cartago'),
    ('Heredia'),
    ('Guanacaste'),
    ('Puntarenas'),
    ('Limón');

-- Tabla Cantones
CREATE TABLE Cantones (
    id_canton INT AUTO_INCREMENT PRIMARY KEY,
    id_provincia INT NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    FOREIGN KEY (id_provincia) REFERENCES Provincias(id_provincia)
);
INSERT INTO Cantones (id_provincia, nombre) VALUES
    (1, 'San José'),
    (1, 'Escazú'),
    (1, 'Desamparados'),
    (2, 'Alajuela'),
    (2, 'San Ramón'),
    (2, 'Grecia'),
    (3, 'Cartago'),
    (3, 'Paraíso'),
    (3, 'Turrialba'),
    (4, 'Heredia'),
    (4, 'Barva'),
    (4, 'Santa Bárbara'),
    (5, 'Liberia'),
    (5, 'Nicoya'),
    (5, 'Santa Cruz'),
    (6, 'Puntarenas'),
    (6, 'Esparza'),
    (6, 'Golfito'),
    (7, 'Limón'),
    (7, 'Pococí'),
    (7, 'Guácimo');


-- Tabla Distritos
CREATE TABLE Distritos (
    id_distrito INT AUTO_INCREMENT PRIMARY KEY,
    id_canton INT NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    FOREIGN KEY (id_canton) REFERENCES Cantones(id_canton)
);
INSERT INTO Distritos (id_canton, nombre) VALUES
    (1, 'Carmen'),
    (1, 'Merced'),
    (1, 'Hospital'),
    (2, 'San Antonio'),
    (2, 'San Miguel'),
    (2, 'San Rafael'),
    (3, 'San Rafael Abajo'),
    (3, 'San Antonio'),
    (3, 'San Juan de Dios'),
    (4, 'Alajuela'),
    (4, 'San Juan'),
    (4, 'Carrizal'),
    (5, 'San Ramón'),
    (5, 'Santiago'),
    (5, 'San Isidro'),
    (6, 'Grecia'),
    (6, 'San Isidro'),
    (6, 'San José'),
    (7, 'Oriental'),
    (7, 'Occidental'),
    (7, 'Carmen'),
    (8, 'Paraíso'),
    (8, 'Santiago'),
    (8, 'Orosi'),
    (9, 'Turrialba'),
    (9, 'Pacayas'),
    (9, 'La Suiza'),
    (10, 'Heredia'),
    (10, 'Mercedes'),
    (10, 'San Francisco'),
    (11, 'Barva'),
    (11, 'San Pedro'),
    (11, 'San Pablo'),
    (12, 'Santa Bárbara'),
    (12, 'San Pedro'),
    (12, 'San Juan'),
    (13, 'Liberia'),
    (13, 'Cañas Dulces'),
    (13, 'Mayorga'),
    (14, 'Nicoya'),
    (14, 'Mansión'),
    (14, 'Quebrada Honda'),
    (15, 'Santa Cruz'),
    (15, 'Cabo Velas'),
    (15, 'Tamarindo'),
    (16, 'Puntarenas'),
    (16, 'Chacarita'),
    (16, 'Chira'),
    (17, 'Esparza'),
    (17, 'San Juan Grande'),
    (17, 'Caldera'),
    (18, 'Limón'),
    (18, 'Matina'),
    (18, 'Guápiles'),
    (19, 'Pococí'),
    (19, 'Guápiles'),
    (19, 'Cariari'),
    (20, 'Guácimo'),
    (20, 'Río Jiménez'),
    (20, 'Duacarí');


-- Tabla Direcciones
CREATE TABLE Direcciones (
    id_direccion INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    id_provincia INT NOT NULL,
    id_canton INT NOT NULL,
    id_distrito INT NOT NULL,
    direccion_exacta VARCHAR(255) NOT NULL,
    FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario),
    FOREIGN KEY (id_provincia) REFERENCES Provincias(id_provincia),
    FOREIGN KEY (id_canton) REFERENCES Cantones(id_canton),
    FOREIGN KEY (id_distrito) REFERENCES Distritos(id_distrito)
);
INSERT INTO Direcciones (id_usuario, id_provincia, id_canton, id_distrito, direccion_exacta) VALUES
    (1, 1, 1, 1, '123 Calle Principal, San José, Carmen'),
    (2, 1, 2, 2, '456 Calle Secundaria, San José, San Antonio'),
    (3, 2, 14, 28, '789 Calle Terciaria, Nicoya, Mansión');

-- Tabla Subcategorias
CREATE TABLE Subcategorias (
    id_subcategoria INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    id_categoria INT NOT NULL,
    FOREIGN KEY (id_categoria) REFERENCES Categorias(id_categoria)
);
-- Insertar subcategorias de ejemplo
-- Insertar subcategorias
INSERT INTO Subcategorias (nombre, descripcion, id_categoria) VALUES
('Gafas de Sol', 'Subcategoría de gafas de sol', 1),
('Gafas Graduadas', 'Subcategoría de gafas graduadas', 1),
('Gafas Deportivas', 'Subcategoría de gafas deportivas', 1),
('Cuerdas y Cadenas para Gafas', 'Subcategoría de cuerdas y cadenas para gafas', 4),
('Estuches para Gafas', 'Subcategoría de estuches para gafas', 4),
('Lentes de Contacto Rígidos', 'Subcategoría de lentes de contacto rígidos', 2),
('Lentes de Contacto Uso Especial', 'Subcategoría de lentes de contacto para uso especial', 2),
('Limpiadores y Toallitas', 'Subcategoría de limpiadores y toallitas para gafas', 4);

-- Opcional: Obtener los registros insertados
SELECT * FROM Subcategorias;

