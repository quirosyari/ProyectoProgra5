<?php
class ListProductoModel
{
    public $enlace;

    public function __construct()
    {
        $this->enlace = new MySqlConnect();
    }
    public function index()
    {
        try {
            //Consulta sql
                        $vSql = "SELECT 
                p.id_producto,
                p.nombre AS nombre_producto,
                p.descripcion,
                p.precio,
                c.nombre AS nombre_categoria
            FROM Productos p
            JOIN Categorias c ON c.id_categoria = p.id_categoria
            LIMIT 0, 2000; ";

            //Ejecutar la consulta
            $vResultado = $this->enlace->ExecuteSQL($vSql);

            // Retornar el objeto
            return $vResultado;
        } catch (Exception $e) {
            die($e->getMessage());
        }
    }

    public function obtenerProducto($id)
{
    try {
        $categoriaM = new CategoriaModel();

        // Consulta SQL para obtener el producto por su ID
        $vSql = "SELECT * FROM productos WHERE id = '$id';";

        // Ejecutar la consulta
        $vResultado = $this->enlace->ExecuteSQL($vSql);
        if (!empty($vResultado)) {
            //Obtener objeto
            $vResultado= $vResultado[0];

            //---Categoria
            $categoria = $categoriaM->obtenerCategoria($vResultado->id_categoria);
            //Asignar director al objeto  
            $vResultado->categoria= $categoria;
        }
            
        // Retornar el objeto
        return $vResultado;
    } catch (Exception $e) {
        return json_encode(['error' => $e->getMessage()]);
    }
}

}    
    
