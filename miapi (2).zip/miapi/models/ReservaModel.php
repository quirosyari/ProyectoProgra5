<?php
class ReservaModel
{
    public $enlace;

    public function __construct()
    {
        $this->enlace = new MySqlConnect(); // Suponiendo que MySqlConnect es tu clase de conexión a MySQL
    }

    public function listarReservas($idSucursal)
    {
        try {
            // Consulta para obtener las reservas del encargado
            $vSql = "SELECT r.id_reserva, r.fecha_reserva, s.nombre AS servicio_nombre, r.estado_reserva, su.nombre AS nombre_sucursal, us.id_usuario
                    FROM reservas r
                    JOIN servicios s ON r.id_servicio = s.id_servicio
                    JOIN sucursales su ON r.id_sucursal = su.id_sucursal
                    JOIN usuarios_sucursales us ON su.id_sucursal = us.id_sucursal
                    WHERE su.id_sucursal = '$idSucursal'
                    ORDER BY r.fecha_reserva DESC;";
            //Ejecutar la consulta
            $vResultado = $this->enlace->ExecuteSQL ($vSql);
            if (!empty($vResultado)) {
                //Obtener objeto
                $vResultado= $vResultado[0];
            }
    return $vResultado;
        } catch (PDOException $e) {
            die('Error al obtener las reservas: ' . $e->getMessage());
        }
    }
}
