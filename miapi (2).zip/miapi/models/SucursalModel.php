<?php

class SucursalModel
{
    public $enlace;

    public function __construct()
    {
        $this->enlace = new MySqlConnect();
    }

    /**
     * Listar todos los productos
     * @return array Lista de objetos de productos
     */
    public function index()
    {
        try {
            $vSQL = "SELECT * FROM sucursales;";
            $vResultado = $this->enlace->ExecuteSQL($vSQL);
            return $vResultado;
        } catch (Exception $e) {
            die("" . $e->getMessage());
        }
    }
}