<?php
class CategoriaModel
{
    public $enlace;
    public function __construct()
    {
        $this->enlace = new MySqlConnect();
    }
    /*Listar */
    public function index(){
        try {
            // Consulta SQL
            $vSql = " SELECT * FROM categorias;";
            // Ejecutar la consulta
            $vResultado = $this->enlace->ExecuteSQL($vSql);
                
            // Retornar el objeto
            return $vResultado;
        } catch (Exception $e) {
            die($e->getMessage());
        }
    }
    public function obtenerCategoria($id){
        try {
                $vSql = "SELECT * FROM categorias where id_categoria=$id";
            
             //Ejecutar la consulta
			$vResultado = $this->enlace->ExecuteSQL ( $vSql);
			// Retornar el objeto
			return $vResultado;
		} catch ( Exception $e ) {
			die ( $e->getMessage () );
		}
    }

}