<?php

class ProductoModel
{
    public $enlace;

    public function __construct()
    {
        $this->enlace = new MySqlConnect();
    }

    /**
     * Listar todos los productos
     * @return array Lista de objetos de productos
     */
    public function index()
    {
        try {
            $vSQL = "SELECT id_producto,nombre,descripcion,precio,id_categoria FROM productos";
            $vResultado = $this->enlace->ExecuteSQL($vSQL);
            return $vResultado;
        } catch (Exception $e) {
            die("" . $e->getMessage());
        }
    }
        /**
     * Obtener un producto
     * @param $id del producto
     * @return $vresultado - Objeto 
     */
    //


  public function obtenerProducto($id){
    try {
        $categoriaM = new CategoriaModel;
        //Consulta sql
        $vSql = "SELECT p.nombre,p.id_producto,p.precio,p.descripcion,p.id_categoria, c.nombre as nombre_categoria 
                 FROM productos p
                 LEFT JOIN categorias c ON p.id_categoria = c.id_categoria
                 WHERE p.id_producto ='$id';";

        
        //Ejecutar la consulta
        $vResultado = $this->enlace->ExecuteSQL ($vSql);
        if (!empty($vResultado)) {
            //Obtener objeto
            $vResultado= $vResultado[0];

            //---Categorias
    
            $categoria = $categoriaM->obtenerCategoria($vResultado->id_categoria);
            //Asignar categoria al objeto  
            $vResultado->categoria= $categoria;
        }
            
        // Retornar el objeto
        return $vResultado;
    } catch ( Exception $e ) {
        die ( $e->getMessage () );
    }
}

}

